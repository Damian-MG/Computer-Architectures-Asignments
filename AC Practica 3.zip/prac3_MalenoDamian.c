#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <strings.h>
#include <stdbool.h>
#include <assert.h>
#include <pthread.h>


#define N (4000L) //WE WILL CHANGE THIS PARAMETER MANUALLY TAKING AS VALUES: 2000,3000,4000
#define ND (N*N/100)



//////////////////////////////// DECLARATIONS ////////////////////////////////////////////
int A[N][N],B[N][N],C[N][N],CD[N][N];
int neleC = 0;
long long Suma=0;
int thread_number=0;
pthread_mutex_t lock; 		//global semaphore
clock_t iniTime=0, finalTime =0;

//////////////////////////////////////////////////////////////////////////////////////////


struct Hilo {			// the structure Hilo will hold the limits for each thread
    int start,finish;
};


struct {
    int i,j,v;
}AD[ND];



/////////////////////////////// THREAD'S CODES ///////////////////////////////////////////
    //This is the code for the optional parallelization// 
    /*// Comprovacio MD x M -> M i MD x MD -> M
    Suma =  neleC = 0;
    for (i=0;i<N;i++)
        for(j=0;j<N;j++)
         {
             Suma += CD[i][j];
             if (CD[i][+j]) neleC++;
             //if (C[i][j] != CD[i][j])
             //   printf("Diferencies C i CD pos %d,%d: %d != %d\n",i,j,C[i][j],CD[i][j]);
         }
    */
void *optional_parallelization(struct Hilo *hilo){
    int y = (int)hilo->start;
    int z = (int)hilo->finish;
    for (y;y<z;y++)
        for(int j=0;j<N;j++)
         {
	     pthread_mutex_lock(&lock);
             Suma += CD[j][y];
             if (CD[+j][y]) neleC++;
             pthread_mutex_unlock(&lock);
    	 }
    }

    //This is the code we got to parallelize//
    /*//Matriu dispersa per matriu
    for(i=0;i<N;i++)
        for (k=0;k<ND;k++)
            CD[AD[k].i][i] += AD[k].v * B[AD[k].j][i];
    */
void *thread(struct Hilo *hilo){	
    int i = (int)hilo->start;
    for (i; i<(int)hilo->finish; i++)
    for (int k=0;k<ND;k++)
            CD[AD[k].i][i] += AD[k].v * B[AD[k].j][i];
    optional_parallelization(hilo);
    }
//////////////////////////////////////////////////////////////////////////////////////////

int main(int nargs, char* argv[])
{

    int i,j,k=0;
    int start,finish=0;
    double time_spent=0;

    assert(nargs == 2);
    int thread_number = atoi(argv[1]);	//thred_number is given by parameter
    struct Hilo hilo[thread_number];

    iniTime = clock();
    bzero(A,sizeof(int)*(N*N));
    bzero(C,sizeof(int)*(N*N));
    bzero(CD,sizeof(int)*(N*N));
    

    for (i=0;i<N;i++)
        for (j=0;j<N;j++)
            B[i][j] = rand()%1000;
    
    for(k=0;k<ND;k++)
    {
        AD[k].i=rand()%(N-1);
        AD[k].j=rand()%(N-1);
        AD[k].v=rand()%100+1;
        while (A[AD[k].i][AD[k].j]) {
            if(AD[k].i < AD[k].j)
                AD[k].i = (AD[k].i + 1)%N;
            else 
                AD[k].j = (AD[k].j + 1)%N;
        }
        A[AD[k].i][AD[k].j] = AD[k].v;
    }

    ////Matriu x matriu original (recorregut de C per columnes)
    //for (i=0;i<N;i++)
    //    for (j=0;j<N;j++)
    //        for (k=0;k<N;k++)
    //            C[j][i] += A[j][k] * B[k][i];
 
    
    pthread_mutex_init(&lock, NULL);	// initalizing semaphore
    printf("Side size of the matrix %i \n", N);
    
/////////////////////////////// THREAD CREATION ///////////////////////////////////////////
    pthread_t threads[thread_number];
    int portion = N / thread_number;//portion to be completed by an usual thread
    bool uneven = false;
    if (N%thread_number != 0)uneven = true;

    finalTime = clock(); //end of the parallelization
    
    for (int t=0; t<thread_number; t++)
    {
	if (uneven == false){
		hilo[t].start = t*portion;
		hilo[t].finish = (t+1)*portion;
		printf("Creating thread %i Range %i to %i \n", t+1, hilo[t].start, hilo[t].finish);
		//Creating the new thread
		pthread_create(&threads[t], NULL, thread, (void *)&hilo[t]);
		
	}else{ //uneven == TRUE, the last thread will deal with the uneven chunk
		if (t == thread_number-1){
			hilo[t].start = t*portion;
			hilo[t].finish = N;
		}else{
			hilo[t].start = t*portion;
			hilo[t].finish = (t+1)*portion;
		}
		//Creating the new thread
		pthread_create(&threads[t], NULL, thread, (void *)&hilo[t]);		
	}
	printf("Creating thread %i Range %i to %i \n", t+1, hilo[t].start, hilo[t].finish);
    }
///////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////// THREAD DESTRUCTION ////////////////////////////////////////
   for(int i=0; i<thread_number; i++){	//waiting for the threads to end	
	pthread_join(threads[i], (void **)NULL);
	fprintf(stderr,"End of thread %i\n",i+1);
	} 
    
///////////////////////////////////////////////////////////////////////////////////////////
   
    pthread_mutex_destroy(&lock);	// destroying semaphore

    printf ("\nNumber of elements of the sparse matrix C %d\n",neleC);
    printf("Sum of the elements of C %lld \n",Suma);
    time_spent = (double) (finalTime-iniTime)/CLOCKS_PER_SEC;
    printf("Not parallelizable fraction F %f\n",time_spent);
    
////////////////////////////////////////////////////////////////////////////////////////// 
    exit(0);	//this way it does not exit on the other error
//////////////////////////////////////////////////////////////////////////////////////////
}
