#!/bin/bash

parameters=("-bpred gskew -bpred:Gskew 1 1024 5 0");

#"-bpred 2lev -bpred:2lev 1 4 2 0" "-bpred 2lev -bpred:2lev 1 16 4 0" "-bpred 2lev -bpred:2lev 1 64 6 0" "-bpred 2lev -bpred:2lev 1 256 8 0" "-bpred 2lev -bpred:2lev 1 1024 10 0" "-bpred 2lev -bpred:2lev 1 4 1 0" "-bpred 2lev -bpred:2lev 1 16 3 0" "-bpred 2lev -bpred:2lev 1 64 5 0" "-bpred 2lev -bpred:2lev 1 256 7 0" "-bpred 2lev -bpred:2lev 1 1024 9 0" "-bpred 2lev -bpred:2lev 1 8 2 0" "-bpred 2lev -bpred:2lev 1 32 4 0" "-bpred 2lev -bpred:2lev 1 128 6 0" "-bpred 2lev -bpred:2lev 1 512 8 0" "-bpred 2lev -bpred:2lev 1 2048 10 0"

#"-bpred gskew -bpred:Gskew 1 4 1 0" "-bpred gskew -bpred:Gskew 1 16 2 0" "-bpred gskew -bpred:Gskew 1 64 3 0" "-bpred gskew -bpred:Gskew 1 256 4 0" "-bpred gskew -bpred:Gskew 1 1024 5 0"

#"-bpred nottaken" "-bpred taken" "-bpred perfect" "-bpred bimod -bpred:bimod 8" "-bpred bimod -bpred:bimod 32" "-bpred bimod -bpred:bimod 128" "-bpred bimod -bpred:bimod 512" "-bpred bimod -bpred:bimod 2048" "-bpred 2lev -bpred:2lev 1 8 3 1" "-bpred 2lev -bpred:2lev 1 32 5 1" "-bpred 2lev -bpred:2lev 1 128 7 1" "-bpred 2lev -bpred:2lev 1 512 9 1" "-bpred 2lev -bpred:2lev 1 2048 11 1" "-bpred 2lev -bpred:2lev 1 8 3 0" "-bpred 2lev -bpred:2lev 1 32 5 0" "-bpred 2lev -bpred:2lev 1 128 7 0" "-bpred 2lev -bpred:2lev 1 512 9 0" "-bpred 2lev -bpred:2lev 1 2048 11 0" "-bpred 2lev -bpred:2lev 4 4 2 0" "-bpred 2lev -bpred:2lev 8 16 4 0" "-bpred 2lev -bpred:2lev 16 64 6 0" "-bpred 2lev -bpred:2lev 32 256 8 0" "-bpred 2lev -bpred:2lev 64 1024 10 0" "-bpred 2lev -bpred:2lev 32 2048 11 0"


echo "" > temporal.txt

echo "" > Resultats.txt
j=0
for i in ${parameters[@]}; do

echo -e ${parameters[$j]} >> Resultats.txt

echo -e "\nApplu:" >> Resultats.txt
simplesimgskew/sim-outorder -fastfwd 50000000 -max:inst 10000000 ${parameters[$j]} -redir:sim temporal.txt Benchmarks/applu/exe/applu.exe < Benchmarks/applu/data/ref/applu.in > Prova/applu.out 2> Prova/applu.err
echo $(grep IPC temporal.txt | cut -d "#" -f 1) >> Resultats.txt
echo $(grep .bpred_dir_rate temporal.txt | cut -d "#" -f 1) >> Resultats.txt

echo -e "\nCrafty:" >> Resultats.txt
simplesimgskew/sim-outorder -fastfwd 50000000 -max:inst 10000000 ${parameters[$j]} -redir:sim temporal.txt Benchmarks/crafty/exe/crafty.exe < Benchmarks/crafty/data/ref/crafty.in > Prova/crafty.out 2> Prova/crafty.err
echo $(grep IPC temporal.txt | cut -d "#" -f 1) >> Resultats.txt
echo $(grep .bpred_dir_rate temporal.txt | cut -d "#" -f 1) >> Resultats.txt

echo -e "\nMesa:" >> Resultats.txt
simplesimgskew/sim-outorder -fastfwd 50000000 -max:inst 10000000 ${parameters[$j]} -redir:sim temporal.txt Benchmarks/mesa/exe/mesa.exe -frames 1000 -meshfile Benchmarks/mesa/data/ref/mesa.in -ppmfile Benchmarks/mesa/data/ref/mesa.ppm
echo $(grep IPC temporal.txt | cut -d "#" -f 1) >> Resultats.txt
echo $(grep .bpred_dir_rate temporal.txt | cut -d "#" -f 1) >> Resultats.txt

echo -e "\nVortex:" >> Resultats.txt
cd Benchmarks/vortex/data/ref/
../../../../simplesimgskew/sim-outorder -fastfwd 50000000 -max:inst 10000000 ${parameters[$j]} -redir:sim ../../../../temporal.txt ../../exe/vortex.exe lendian1.raw > vortex1.out2 2> vortex1.err  
cd ../../../../
echo $(grep IPC temporal.txt | cut -d "#" -f 1) >> Resultats.txt
echo $(grep .bpred_dir_rate temporal.txt | cut -d "#" -f 1) >> Resultats.txt

echo -e "\nVpr:" >> Resultats.txt
simplesimgskew/sim-outorder -fastfwd 50000000 -max:inst 10000000 ${parameters[$j]} -redir:sim temporal.txt Benchmarks/vpr/exe/vpr.exe Benchmarks/vpr/data/ref/net.in Benchmarks/vpr/data/ref/arch.in Benchmarks/vpr/data/ref/route.out -nodisp -route_only -route_chan_width 15 -pres_fac_mult 2 -acc_fac 1 -first_iter_pres_fac 4 -initial_pres_fac 8 > Prova/route_log.out 2> Prova/route_log.err
echo $(grep IPC temporal.txt | cut -d "#" -f 1) >> Resultats.txt
echo $(grep .bpred_dir_rate temporal.txt | cut -d "#" -f 1) >> Resultats.txt

echo -e "\n\n" >> Resultats.txt	

let j=j+1
	if [ $j == 5 ]; then 
		break 
	fi
done
rm costs.out
rm game.001
rm temporal.txt
exit 0
