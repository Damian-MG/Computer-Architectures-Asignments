#! /bin/bash

echo "Config default" > Results_intel.txt

bash execute.sh intel_configs/intel_config Results_intel.txt
echo -e "\n\n\nConfig2: Ruu 256 -> 512" >> Results_intel.txt
bash execute.sh intel_configs/intel_config2 Results_intel.txt
echo -e "\n\n\nConfig3: Lsq 256 -> 512" >> Results_intel.txt
bash execute.sh intel_configs/intel_config3 Results_intel.txt
echo -e "\n\n\nConfig5: ialu 4 -> 5" >> Results_intel.txt
bash execute.sh intel_configs/intel_config4 Results_intel.txt
echo -e "\n\n\nConfig6: imult 2 -> 3" >> Results_intel.txt
bash execute.sh intel_configs/intel_config5 Results_intel.txt
echo -e "\n\n\nConfig7: memport 4 -> 5" >> Results_intel.txt
bash execute.sh intel_configs/intel_config6 Results_intel.txt
echo -e "\n\n\nConfig8: fpalu 3 -> 4" >> Results_intel.txt
bash execute.sh intel_configs/intel_config7 Results_intel.txt
echo -e "\n\n\nConfig9: fpmult 3 -> 4" >> Results_intel.txt
bash execute.sh intel_configs/intel_config8 Results_intel.txt
echo -e "\n\n\nConfig10: fetch 4 -> 5" >> Results_intel.txt
bash execute.sh intel_configs/intel_config9 Results_intel.txt
echo -e "\n\n\nConfig11: decode 5 -> 6" >> Results_intel.txt
bash execute.sh intel_configs/intel_config10 Results_intel.txt
echo -e "\n\n\nConfig11: issue 6 -> 7" >> Results_intel.txt
bash execute.sh intel_configs/intel_config11 Results_intel.txt
echo -e "\n\n\nConfig12:fetch, decode, issue 6" >> Results_intel.txt
bash execute.sh intel_configs/intel_config12 Results_intel.txt
echo -e "\n\n\nConfig13: dl1 sets 64 -> 128" >> Results_intel.txt
bash execute.sh intel_configs/intel_config13 Results_intel.txt
echo -e "\n\n\nConfig14: dl1 size 64 -> 128" >> Results_intel.txt
bash execute.sh intel_configs/intel_config14 Results_intel.txt
echo -e "\n\n\nConfig15: dl1 asociatividad 8 -> 16" >> Results_intel.txt
bash execute.sh intel_configs/intel_config15 Results_intel.txt
echo -e "\n\n\nConfig16: il1 sets 64 -> 128" >> Results_intel.txt
bash execute.sh intel_configs/intel_config16 Results_intel.txt
echo -e "\n\n\nConfig17: il1 size 64 -> 128" >> Results_intel.txt
bash execute.sh intel_configs/intel_config17 Results_intel.txt
echo -e "\n\n\nConfig18: il1 asociatividad 8 -> 16" >> Results_intel.txt
bash execute.sh intel_configs/intel_config18 Results_intel.txt
echo -e "\n\n\nConfig19: dl2 sets 1024 -> 2048" >> Results_intel.txt
bash execute.sh intel_configs/intel_config19 Results_intel.txt
echo -e "\n\n\nConfig20: dl2 size 64 -> 128" >> Results_intel.txt
bash execute.sh intel_configs/intel_config20 Results_intel.txt
echo -e "\n\n\nConfig21: dl2 asociatividad 8 -> 16" >> Results_intel.txt
bash execute.sh intel_configs/intel_config21 Results_intel.txt
echo -e "\n\n\nConfig22: mem:width 64 -> 128" >> Results_intel.txt
bash execute.sh intel_configs/intel_config22 Results_intel.txt
echo -e "\n\n\nConfig23: commit 10 -> 11" >> Results_intel.txt
bash execute.sh intel_configs/intel_config23 Results_intel.txt



