#! /bin/bash

echo "Config default" > Results_amd.txt

bash executeAMD.sh amd_configs/amd_config Results_amd.txt
echo -e "\n\n\nConfig2: Ruu 256 -> 512" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config2 Results_amd.txt
echo -e "\n\n\nConfig3: Lsq 128 -> 256" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config3 Results_amd.txt
echo -e "\n\n\nConfig5: ialu 4 -> 5" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config4 Results_amd.txt
echo -e "\n\n\nConfig6: imult 1 -> 2" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config5 Results_amd.txt
echo -e "\n\n\nConfig7: memport 4 -> 5" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config6 Results_amd.txt
echo -e "\n\n\nConfig8: fpalu 4 -> 5" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config7 Results_amd.txt
echo -e "\n\n\nConfig9: fpmult 2 -> 3" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config8 Results_amd.txt
echo -e "\n\n\nConfig10: fetch 8 -> 9" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config9 Results_amd.txt
echo -e "\n\n\nConfig11: decode 8 -> 9" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config10 Results_amd.txt
echo -e "\n\n\nConfig11: issue 10 -> 11" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config11 Results_amd.txt
echo -e "\n\n\nConfig12: commit 8 -> 9" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config12 Results_amd.txt
echo -e "\n\n\nConfig13: dl1 sets 256 -> 512" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config13 Results_amd.txt
echo -e "\n\n\nConfig14: dl1 size 64 -> 128" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config14 Results_amd.txt
echo -e "\n\n\nConfig15: dl1 asociatividad 4 -> 8" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config15 Results_amd.txt
echo -e "\n\n\nConfig16: il1 sets 64 -> 128" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config16 Results_amd.txt
echo -e "\n\n\nConfig17: il1 size 64 -> 128" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config17 Results_amd.txt
echo -e "\n\n\nConfig18: il1 asociatividad 8 -> 16" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config18 Results_amd.txt
echo -e "\n\n\nConfig19: dl2 sets 1024 -> 2048" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config19 Results_amd.txt
echo -e "\n\n\nConfig20: dl2 size 64 -> 128" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config20 Results_amd.txt
echo -e "\n\n\nConfig21: dl2 asociatividad 8 -> 16" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config21 Results_amd.txt
echo -e "\n\n\nConfig22: mem:width 32 -> 64" >> Results_amd.txt
bash executeAMD.sh amd_configs/amd_config22 Results_amd.txt


