#!/bin/bash

config=$1
result=$2


echo "Applu:" >> $result
simplesim-3.0_acx/sim-outorder -config $config -redir:sim temporal2.txt Benchmarks/applu/exe/applu.exe < Benchmarks/applu/data/ref/applu.in > Prova/applu.out 2> Prova/applu.err
echo $(grep sim_IPC temporal2.txt) >> $result
#echo $(grep ruu_occupancy temporal2.txt) >> $result
#echo $(grep lsq_occupancy temporal2.txt) >> $result
#echo $(grep avg_sim_slip temporal2.txt) >> $result

echo -e "\nCrafty:" >> $result 
simplesim-3.0_acx/sim-outorder -config $config -redir:sim temporal2.txt Benchmarks/crafty/exe/crafty.exe < Benchmarks/crafty/data/ref/crafty.in > Prova/crafty.out 2> Prova/crafty.err
echo $(grep sim_IPC temporal2.txt) >> $result

echo -e "\nMesa:" >> $result
simplesim-3.0_acx/sim-outorder -config $config -redir:sim temporal2.txt Benchmarks/mesa/exe/mesa.exe -frames 1000 -meshfile Benchmarks/mesa/data/ref/mesa.in -ppmfile Benchmarks/mesa/data/ref/mesa.ppm
echo $(grep sim_IPC temporal2.txt) >> $result

echo -e "\nVortex:" >> $result
cd Benchmarks/vortex/data/ref/
../../../../simplesim-3.0_acx/sim-outorder -config ../../../../$config -redir:sim ../../../../temporal2.txt ../../exe/vortex.exe lendian1.raw > vortex1.out2 2> vortex1.err  
cd ../../../../
echo $(grep sim_IPC temporal2.txt) >> $result

echo -e "\nVpr:" >> $result
simplesim-3.0_acx/sim-outorder -config $config -redir:sim temporal2.txt Benchmarks/vpr/exe/vpr.exe Benchmarks/vpr/data/ref/net.in Benchmarks/vpr/data/ref/arch.in Benchmarks/vpr/data/ref/route.out -nodisp -route_only -route_chan_width 15 -pres_fac_mult 2 -acc_fac 1 -first_iter_pres_fac 4 -initial_pres_fac 8 > Prova/route_log.out 2> Prova/route_log.err
echo $(grep sim_IPC temporal2.txt) >> $result

rm temporal2.txt
